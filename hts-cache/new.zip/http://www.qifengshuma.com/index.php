<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<script type="text/javascript" src="/assets/87f5935c/jquery.min.js"></script>
<title>深圳市旗锋数码科技有限公司</title>
<meta name="generator" content="BageCMS CMS" />
<meta name="author" content="shuguang" />
<meta name="keywords" content="手机pos机">
<meta name="description" content="旗锋数码  即付宝,旗锋数码 ,银联,手机POS,手机刷卡器,移动POS机,蓝牙POS机">
<link rel="stylesheet" href="/themes/default/css/style.css">
<link rel="stylesheet" href="/themes/default/css/skin.css">
<script type="text/javascript" src="/static/js/jquery.SuperSlide.2.1.js"></script>
</head>
<body>
<div class="container">
<!--头-->
<div id="header" class="header">
  <div class="wrap">
    <div class="logo floatL">
      <h1>旗锋数码</h1>
    </div>
    <div class="nav floatR">
      <div class="clear">
        <dl class="tnLeft">
          <dd>
            <h3><a href="/index.php">首页</a></h3>
          </dd>
          <dd>
            <h3><a href="/index.php?r=page/show&name=about">关于我们</a></h3>
          </dd>
                              <dd>
            <h3><a href="/index.php?r=post/index&catalog=news">新闻资讯</a></h3>
            <ul>
                            <li><a href="/index.php?r=post/index&catalog=co-news">企业动态</a></li>
                            <li><a href="/index.php?r=post/index&catalog=company-notice">企业公告</a></li>
                          </ul>
          </dd>
                                                                      <dd>
            <h3><a href="/index.php?r=page/show&name=bmservice">便民服务</a></h3>
          </dd>
          <dd>
            <h3><a href="/index.php?r=page/show&name=client">下载中心</a></h3>
             <ul style="display: none;">
              <li><a href="/index.php?r=page/show&name=client">客户端下载 </a></li>
              <li><a href="/index.php?r=page/show&name=detail-file">说明资料 </a></li>
              </ul>
          </dd>
          <dd>
            <h3><a href="/index.php?r=question">招商代理</a></h3>
          </dd>
          <dd>
            <h3><a href="/index.php?r=page/show&name=contact">联系我们</a></h3>
          </dd>
        </dl>
      </div>
    </div>
    <script type="text/javascript">jQuery(".nav").slide({ type:"menu",  titCell:"dd", targetCell:"ul", delayTime:0,defaultPlay:false,returnDefault:true  });	</script> 
  </div>
</div>
<!--/头--> 
<script type="text/javascript">
$(document).ready(function(){
  $("#none").click(function(){
  $(".ourserver").hide(200);
  });
  $("#blok").click(function(){
  $(".ourserver").show(200);
  });
});
</script>
<div class="ourserver" style="display: block;"> <a id="none">关闭</a> <div class="ser_title"><span><a href="/index.php?r=question">招商加盟</a></span></div> <div class="ser_content"> <div class="content_title" style="border-bottom:1px solid #ccc;"><p>13528253868 杨生</p><p>0760-88625381</p></div><div style="margin:10px 0 0; text-align:center;"><a title="点击这里给我发消息" href="http://wpa.qq.com/msgrd?v=3&amp;uin=809891888&amp;site=www.cactussoft.cn&amp;menu=yes" target="_blank"><img src="http://wpa.qq.com/pa?p=2:809891888:41"></a></div><div class="content_code"> <img src="themes/default/images/ma.gif"> <span>扫二维码关注</span> <div class="clear"></div> </div> </div> </div>
<div class="ourserverzk"><a id="blok">展开</a></div>
<!--广告-->
<div class="banner">
  <div class="bd">
    <ul>
		     <li _src="url(https://img.alicdn.com/imgextra/i2/2592944215/TB25Na1hpXXXXX2XpXXXXXXXXXX_!!2592944215.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-12355944427.2.oqPJAV&id=522126496967"></a></li>
	 		     <li _src="url(https://img.alicdn.com/imgextra/i2/1710112802/TB2OohRgVXXXXatXXXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://item.taobao.com/item.htm?spm=2013.1.20141001.1.OTrXnC&id=45315607090&scm=1007.10115.13120.100200300000000&pvid=df27e776-"></a></li>
	 		     <li _src="url(https://img.alicdn.com/imgextra/i4/1710112802/TB2_MxVgpXXXXcUXXXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-12355944427.11.TsOTV2&id=520431821032"></a></li>
	 		     <li _src="url(https://img.alicdn.com/imgextra/i2/1710112802/TB2ISJWgVXXXXXYXXXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://img.alicdn.com/imgextra/i4/1710112802/TB20VNygXXXXXXqXpXXXXXXXXXX_!!1710112802.jpg?t=1444692155000"></a></li>
	 		     <li _src="url(https://img.alicdn.com/imgextra/i4/1710112802/TB2zF0BgVXXXXaqXpXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-11975568868.2.pSBVZp&id=520903527866"></a></li>
	 		     <li _src="url(https://img.alicdn.com/imgextra/i4/1710112802/TB26mGtgFXXXXb.XXXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"><a target="_blank" href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-11975568868.2.pSBVZp&id=520903527866"></a></li>
	 			 <li _src="url(https://img.alicdn.com/imgextra/i2/1710112802/TB2m2V6gpXXXXaBXXXXXXXXXXXX_!!1710112802.png)" style="background:#DED5A1 center 0 no-repeat;"></li>
		    </ul>
  </div>
  <div class="hd">
    <ul>
    </ul>
  </div>
  <span class="prev"></span><span class="next"></span></div>
<script type="text/javascript">
jQuery(".banner").hover(function(){jQuery(this).find(".prev,.next").stop(true,true).fadeTo(4000,0.5)},function(){jQuery(this).find(".prev,.next").fadeOut()});jQuery(".banner").slide({titCell:".hd ul",mainCell:".bd ul",effect:"fold",autoPlay:true,autoPage:true,trigger:"click",startFun:function(i){var curLi=jQuery(".banner .bd li").eq(i);if(!!curLi.attr("_src")){curLi.css("background-image",curLi.attr("_src")).removeAttr("_src")}}});
</script>
<!--/广告-->

<div class="index">
<div class="index-part-2">
<div class="wrap clear ">
  <section class="main">

    	<div class="wrap">

        	<div class="ind-bak"><span class="lin lin1"></span><span class="lin lin2"></span><span class="lin lin3"></span><span class="lin lin4"></span>

            	<ul class="cf dy-cf">

                	 <li class="l1">
                            <a href="http://www.jfpal.cn" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/04.png);" data-hpic="/templets/jf/images/04.png" data-lpic="/templets/jf/images/04-1.png"></i>金融外包</a>
                    	   
                      </li><li class="l2">
                          <a href="http://www.quanziyun.cn/" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/20150305152448_25407.png);" data-hpic="/templets/jf/images/20150305152448_25407.png" data-lpic="/templets/jf/images/20150305152458_27900.png"></i>圈子电商</a>

                    	  

                      </li><li class="l3">

                    	   <a href="http://www.sdjjyt.com/" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/20150609150636_50600.png);" data-hpic="/templets/jf/images/20150609150636_50600.png" data-lpic="/templets/jf/images/20150609150626_75591.png"></i>电信服务</a>

                      </li><li class="l4">

                    	   <a href="http://baoli.jfpal.com" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/20150805112425_32098.png);" data-hpic="/templets/jf/images/20150805112425_32098.png" data-lpic="/templets/jf/images/20150805112438_92995.png"></i>商业保理</a>

                      </li>      

<li class="l5">

                    	   <a href="http://grzx.jfpal.com/" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/z01.png);" data-hpic="/templets/jf/images/z01.png" data-lpic="/templets/jf/images/z02.png"></i>个人征信</a>

                      </li>   

      </ul>
     
            </div>

        </div>

    </section>
    <section class="main">

    	<div class="wrap">

        	<div class="ind-bak"><span class="lin lin1"></span><span class="lin lin2"></span><span class="lin lin3"></span><span class="lin lin4"></span>

            	<ul class="cf dy-cf">

                	 <li class="l1">

                    	   <a href="http://www.jfpal.com/jsz.html" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/01.png);" data-hpic="/templets/jf/images/01.png" data-lpic="/templets/jf/images/01-1.png"></i>企业征信</a>

                      </li><li class="l2">

                    	   <a href="http://caifu.jfpal.com/" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/02-1.png);" data-hpic="/templets/jf/images/02-1.png" data-lpic="/templets/jf/images/02.png"></i>财富管理</a>

                      </li><li class="l3">

                    	   <a href="http://www.wzpis.com" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/03.png);" data-hpic="/templets/jf/images/03.png" data-lpic="/templets/jf/images/03-1.png"></i>支付服务</a>

                      </li><li class="l4">

                    	  <a href="http://qxpal.com/index.html" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/20150805112329_49408.png);" data-hpic="/templets/jf/images/20150805112329_49408.png" data-lpic="/templets/jf/images/20150805112344_26010.png"></i>便民服务</a>
                      </li>       
<li class="l4">

                    	   <a href="http://www.jfpal.com/jsz.html" target="_blank"><i style="background: url(http://www.jfpal.com/templets/jf/images/z03.png);" data-hpic="/templets/jf/images/z03.png" data-lpic="/templets/jf/images/z04.png"></i>P2P超市</a>

                      </li>        
         </ul>

            </div>

        </div>

    </section>
</div>
</div>
<!--商品-->
<div class="index-part-1">
<div class="wrap clear ">
  <div class="product"> <h1>移动时代，即刷即付</h1> <h4>安全、快捷、用心，致力于创造全新的支付体验，让用户随时随地享受贴身的便利支付服务</h4> <div class="cplist"> <div class="img"><img src="themes/default/images/pro1.jpg" width="205"></div> <h2>即付宝刷卡头</h2> <h4>即付宝手机刷卡器是一款通过音频进行数据传输的刷卡器外设终端，只要将它插入智能手机...</h4> <a href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-11975568868.2.pSBVZp&id=520903527866" target="_blank">查看详情</a> </div> <div class="cplist"> <div class="img"><img src="themes/default/images/pro2.jpg" width="172"></div> <h2>mPOS</h2> <h4>mPOS是一款新推出的创新收单终端，通过蓝牙接口与手机等移动设备连接...</h4> <a href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4024-12143990813.2.34iCNO&id=520913362046&scene=taobao_shop" target="_blank">查看详情</a> </div> <div class="cplist"> <div class="img"><img src="themes/default/images/pro3.jpg" width="195"></div> <h2>开店宝</h2> <h4>开店宝是一款集合收银机、CRM、电子货架、PC机、ERP于一身同时实现支付...</h4> <a href="https://item.taobao.com/item.htm?spm=a1z10.1-c.w4024-12143990813.4.dclXfE&id=520903527866&scene=taobao_shop" target="_blank">查看详情</a> </div> </div>
</div>
</div>
<!--首页模块-->
<div class="index-part-2">
<div class="module clear">
  <div class="wrap">
    <div class="moduleBox post">
      <div class="col">
        <h2>公司公告<em>Notice</em></h2>
       </div>
      <div class="con">
        <ul class="clear">
                    <li><em class="date">2015-11-19</em><h3><a href="/index.php?r=post/show&id=25" target="_blank">尊敬的代理商您好：  由于网信理财多次系统升级维护停止</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=25					" target="_blank">
                    尊敬的代理商您好：  由于网信理财多次系统升级维护，仍无法满足用户体验，故网信理财决定于2015年11月19日24时结束活动补贴活动，进而网信理财推荐活动届时也将停止。从2015年11月20日起将不再计算网信推广奖励，请各代理商及时调整自身业务推广重心，并在11月30日24时前将兑换券录入代理商后台，逾期录入即视为无效。请各代理商做好通知宣导工作。敬请关注后续我司推出的活动！
                             				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-16</em><h3><a href="/index.php?r=post/show&id=24" target="_blank">旗锋科技全城招募项目合伙人</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=24					" target="_blank">
                    无论你是银行信用卡中心工作
人员，还是P2P公司的销售精英，
还是无限极的生意老板或者是平
安保险的业务翘楚，又或者是手
机店的私营老板们，这个项目肯
定适合你！！！
				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-12</em><h3><a href="/index.php?r=post/show&id=20" target="_blank">湖州市长陈伟俊亲临浙江即富金融数据处理有限公司进行考察调研工作</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=20					" target="_blank">
                    2015年10月14日上午湖州市委副书记、市长陈伟俊一行在湖州市经济开发区党委书记、管委会主任施根宝，南太湖科创中心主任池丽萍陪同下莅临浙江即富金融数据处理公司考察指导。浙江即富金融数据处理公司总经理王京松陪同。

陈市长一行人在王总的陪同下参观了公司内部环境，并听取了王总针对公司发展及各项业务的相关工作汇报，王总详细的介绍了目前公司发展历程、规模及取得的成绩，以及在小微商家电子化金融服务上的具体业务及经营范围。陈市长对公司强劲的发展态势及取得的辉煌成绩给予了充分肯定。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-08</em><h3><a href="/index.php?r=post/show&id=18" target="_blank">招商加盟</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=18					" target="_blank">
                    上海即富信息技术有限公司是一家基于移动互联网终端开展便民缴费业务及移动互联网电子商务服务的公司，致力于为广大个人用户、小微企业、会员企业提供最优秀的产品及服务。 公司与中国银联、上海银联均签有多渠道入网协议，获准接入中国银联多渠道系统开展业务，持有独立的多渠道接入机构号。终端、系统平台均通过权威机构的系列安全认证。 依托繁华的陆家嘴金融贸易区，以辨明服务为基础，为圈子电商为模式，做中国最大、最有特色的智能便民电商平台。上海即富信息技术服务有限公司生产的即付宝刷卡器面向全国诚招各级代理商或贴牌商，具体代理政策及要求如下：具有pos收单业务及相关经营项目的企业法人单位，或其他合法经营单位或个人均有资格成为我公司的代理商。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-08</em><h3><a href="/index.php?r=post/show&id=17" target="_blank">好消息！！！</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=17					" target="_blank">
                    真情回馈 多谢大家一直来大家对旗锋的支持，即日起代理商凡一次性购100台蓝牙mpos机赠送一台苹果6S手机，				</a>
           </div>
          </li>
                  </ul>
        <div class="index-more"><a href="/index.php?r=post/index&catalog=company-notice" class="move" target="_blank">查看更多</a></div>
      </div>
    </div>
  </div>
</div>
</div>
<div class="index-part-3">
<div class="module clear">
  <div class="wrap">
    <div class="moduleBox post">
      <div class="col">
        <h2>公司动态<em>NEWS</em></h2>
       </div>
      <div class="con">
        <ul class="clear">
                    <li><em class="date">2015-11-12</em><h3><a href="/index.php?r=post/show&id=22" target="_blank">中国人行称未来支付工具监管要采宽容态度</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=22					" target="_blank">
                    中国人民银行支付结算司副司长樊爽文周四表示，由于支付工具创新太快，未来监管要采宽容的态度，观察期要放长一点，将朝向报备制而不是审批制，主要就风险及客户讯息保护方面定出基本原则。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-12</em><h3><a href="/index.php?r=post/show&id=21" target="_blank">央行鼓励移动金融有卡支付</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=21					" target="_blank">
                    近年来随着网购的飞速发展，快捷支付等无卡交易方式被越来越多的消费者所熟悉，但与此同时，无卡支付的风险也随之暴露。近日，央行在《关于进一步做好金融IC卡应用工作的通知》中明确表示鼓励发卡银行、银行卡清算机构等开展以有卡交易方式为主的移动金融服务。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-04</em><h3><a href="/index.php?r=post/show&id=14" target="_blank">POS机常见问题</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=14					" target="_blank">
                      资金绝对安全，，钱是收到第三方公司的（中国所有的第三方支付都是这样的，如果你跑过来说哪家第三方支付公司不是这样的，我只能说你还只是一个外行），再打到你储蓄卡。
       第三方是央行批准的，根据每天资金交易量，在央行交了保证金的。如果你资金安全出问题，央行动用保证金先行赔付。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-04</em><h3><a href="/index.php?r=post/show&id=13" target="_blank">网信集团CEO盛佳出席中英互联网圆桌会议</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=13					" target="_blank">
                    　10月19日，第六届中英互联网圆桌会议于伦敦召开，网信集团CEO盛佳应邀出席作“互联网金融，世界的机会”主题演讲，并就中英互联网金融发展现状和机遇与中英嘉宾做深入探讨。				</a>
           </div>
          </li>
                    <li><em class="date">2015-11-04</em><h3><a href="/index.php?r=post/show&id=12" target="_blank">复星集团董事长郭广昌等150名企业家随习近平访英</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=12					" target="_blank">
                    　记者注意到，习近平主席访美时，也曾率领一个150人的企业家代表团访问，但上次的随行企业主要集中于互联网、金融、能源等领域。在每次访问中，跟随领导人出访的企业名单，不仅能体现出两国经贸合作的重心，也可能预示着一些大单的签订。				</a>
           </div>
          </li>
                    <li><em class="date">2015-10-18</em><h3><a href="/index.php?r=post/show&id=11" target="_blank">我们的名字叫：《即付宝》</a>
          </h3>
          <div class="desc">
				<a href="					/index.php?r=post/show&id=11					" target="_blank">
                    我们的名字叫：《即付宝》				</a>
           </div>
          </li>
                  </ul>
        <div class="index-more"><a href="/index.php?r=post/index&catalog=co-news" class="move" target="_blank">查看更多</a></div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<!--/首页模块--> 
<!--<script type="text/javascript">
jQuery(".indexGoods").slide({ mainCell:"ul", effect:"leftMarquee", vis:5, autoPlay:true, interTime:50, switchLoad:"_src" });	</script> -->
<div id="footer">
  <div class="wrap clear">
    <div class="act"><p>&nbsp;</p>
      <p>COPYRIGHT © 2014 - 2015 QiFengDigital. ALL RIGHTS RESERVED.深圳市杨氏旗锋数码有限公司 版权所有 &nbsp;&nbsp;( <a href="http://www.miitbeian.gov.cn/" target="_blank">粤ICP备14069625号</a> ) </p>
    </div>
  </div>
</div>
</div>
</body>
</html>

